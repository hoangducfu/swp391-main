/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author mactu
 */
public class Constants {
    public static String GOOGLE_CLIENT_ID = "317266700784-kg2ivgn1cgkturjutcqgmkitdo1o5nl3.apps.googleusercontent.com";

	public static String GOOGLE_CLIENT_SECRET = "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";

	public static String GOOGLE_REDIRECT_URI = "http://localhost:9999/Project_SWP391/loginGoogleHandler";

	public static String GOOGLE_LINK_GET_TOKEN = "https://accounts.google.com/o/oauth2/token";

	public static String GOOGLE_LINK_GET_USER_INFO = "https://www.googleapis.com/oauth2/v1/userinfo?access_token=";

	public static String GOOGLE_GRANT_TYPE = "authorization_code";
}
